package com.example.LeaveManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaveManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
