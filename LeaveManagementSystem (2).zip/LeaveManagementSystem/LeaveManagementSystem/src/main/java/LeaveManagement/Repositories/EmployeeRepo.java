package LeaveManagement.Repositories;

public interface EmployeeRepo {

}
