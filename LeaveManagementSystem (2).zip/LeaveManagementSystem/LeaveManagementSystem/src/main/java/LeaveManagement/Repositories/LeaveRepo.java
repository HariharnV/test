package LeaveManagement.Repositories;

public interface LeaveRepo {

}
