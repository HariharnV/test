package LeaveManagement.Entity;

public class Employee {

}
