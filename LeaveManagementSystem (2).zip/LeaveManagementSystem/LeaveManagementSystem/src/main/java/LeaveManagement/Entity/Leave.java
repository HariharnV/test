package LeaveManagement.Entity;

public class Leave {

}
