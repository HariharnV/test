package LeaveManagement.Controller;

public class EmployeeController {

}
