package LeaveManagement.Controller;

public class LeaveController {

}
